<?php  
class Admin_landing_faq extends Admin_controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('FAQLanding_model');
		$this->load->model('DataSafe_model');
	}
	public function index(){
		$data = [];
		$data['data_faq'] = $this->FAQLanding_model->get_many();
		$this->view( 'Admin_landing_faq/index', $data );
	}
	public function tambah(){	
		if ( isset($_POST['submit']) ) {
			$tambah_data = $this->FAQLanding_model->tambah();
			$this->session->set_flashdata('tambah_data', $tambah_data['msg']);
			redirect('Admin_landing_faq');			
		}
	}

	public function update( $id_landing_faq ){

		// Cek apakah id produk yang ingin di update itu ada atau tidak di tabel. Jika dia tidak ada maka jangan biarkan dia akses form ini
		$row_faq = $this->FAQLanding_model->get_single(['id_landing_faq' => $id_landing_faq ]);
		if ( empty($row_faq) ) {
			$this->session->set_flashdata('update_produk', 'Produk yang ingin di update tidak terdaftar');
			redirect('Admin_landing_faq');
			die;
		}

		
		if ( $this->input->post('submit') ) {

			$update_produk = $this->FAQLanding_model->update( $id_landing_faq );
			$msg = $update_produk['msg'];
			$this->session->set_flashdata('FAQLanding_model', $msg);

			redirect('Admin_landing_faq/update/'.$id_landing_faq);
		}

		$data = [];
		$data['row_faq'] = $row_faq;
		$this->view('Admin_landing_faq/update', $data);

	}


	public function delete_data( $id_landing_faq ){

		$hapus_row = $this->DataSafe_model->delete_safe( 'data_landing_faq',["id_landing_faq" => $id_landing_faq]);
		$msg = $hapus_row['msg'];

		$this->session->set_flashdata('delete_safe', $msg);

		redirect('Admin_landing_faq');
	}

	public function restore_data( $id_landing_faq ){

		$hapus_row = $this->DataSafe_model->restore_safe( 'data_landing_faq',["id_landing_faq" => $id_landing_faq]);
		$msg = $hapus_row['msg'];

		$this->session->set_flashdata('restore_safe', $msg);

		redirect('Admin_landing_faq');
	}


}