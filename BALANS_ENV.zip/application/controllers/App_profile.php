<?php

class App_profile extends App_controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('User_model');
	}
	public function index(){
		$data = [];
		$this->view('App_profile/index', $data);
	}




}