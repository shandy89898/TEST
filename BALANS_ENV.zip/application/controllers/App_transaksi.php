<?php

class App_transaksi extends App_controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('Produk_model');
		$this->load->model('ProdukGambar_model');
		$this->load->model('Keranjang_model');
		$this->load->model('Transaksi_model');
		$this->load->model('User_model');

	}


	public function index(){


		$user_login = $this->Base_model->get_userLogin();

		// $data_param = [ "user_beli" => "", "total_harga" => "", "total_pesanan" => "", "data_checkout_produk" => [ [], [], [] ]  ];
		$data_transaksi = $this->Transaksi_model->get_many( ['status' => 'ACTIVE', 'user_beli' =>  $user_login ] );
		// die;
		$data = [];
		$data['data_transaksi'] = $data_transaksi;
		$data['total_harga_transaksi'] = $this->total_transaksi()['total_harga_transaksi'];
		$this->view('App_transaksi/index', $data); 
	}

	public function total_transaksi(){
		$user_beli = $this->Base_model->get_userLogin();

		$this->db->select('SUM(total_harga) as total_harga_transaksi');
		$this->db->from('data_transaksi');
		$this->db->where('user_beli', $user_beli);
		return $this->db->get()->row_array();
	}


}