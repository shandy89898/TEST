<?php  
class Admin_landing_slide extends Admin_controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('SlideLanding_model');
		$this->load->model('DataSafe_model');
	}
	public function index(){
		$data = [];
		$data['data_indicator'] = $this->SlideLanding_model->get_many();
		$this->view( 'Admin_landing_slide/index', $data );
	}
	public function tambah(){	
		if ( isset($_POST['submit']) ) {
			$tambah_data = $this->SlideLanding_model->tambah();
			$this->session->set_flashdata('tambah_data', $tambah_data['msg']);
			redirect('Admin_landing_slide');			
		}
	}

	public function update( $id_landing_slide ){

		// Cek apakah id produk yang ingin di update itu ada atau tidak di tabel. Jika dia tidak ada maka jangan biarkan dia akses form ini
		$row_slide = $this->SlideLanding_model->get_single(['id_landing_slide' => $id_landing_slide ]);
		if ( empty($row_slide) ) {
			$this->session->set_flashdata('update_produk', 'Produk yang ingin di update tidak terdaftar');
			redirect('Admin_landing_slide');
			die;
		}

		
		if ( $this->input->post('submit') ) {

			$update_produk = $this->SlideLanding_model->update( $id_landing_slide );
			$msg = $update_produk['msg'];
			$this->session->set_flashdata('SlideLanding_model', $msg);

			redirect('Admin_landing_slide/update/'.$id_landing_slide);
		}

		$data = [];
		$data['row_slide'] = $row_slide;
		$this->view('Admin_landing_slide/update', $data);

	}


	public function delete_data( $id_landing_slide ){

		$hapus_row = $this->DataSafe_model->delete_safe( 'data_landing_slide',["id_landing_slide" => $id_landing_slide]);
		$msg = $hapus_row['msg'];

		$this->session->set_flashdata('delete_safe', $msg);

		redirect('Admin_landing_slide');
	}

	public function restore_data( $id_landing_slide ){

		$hapus_row = $this->DataSafe_model->restore_safe( 'data_landing_slide',["id_landing_slide" => $id_landing_slide]);
		$msg = $hapus_row['msg'];

		$this->session->set_flashdata('restore_safe', $msg);

		redirect('Admin_landing_slide');
	}


}