<?php 

class FAQLanding_model extends CI_Model{

	public function get_many( $where = [], $nama_tabel = "data_landing_faq" ){
		// $where itu adalah array associatif [ "nama_kolom" => "value" ]
		// Mengembalikan 2 dimensi dengan banyak data dengan method ->result_array()

		//Where disini bertindak sebagai filter dengan logika AND yang optional atau jika misalnya tidak ada where data tetap diambil tanpa filter
		foreach ($where as $key_kolom => $value) {
			$this->db->where($key_kolom, $value);
		}

		$this->db->order_by('waktu', 'DESC');  // Mengurutkan berdasarkan kolom waktu yang kolom waktunya terbaru

		$result = $this->db->get( $nama_tabel )->result_array();
		if ( $result == null ) {
			$result = [];
		}
		return $result; //Mengembalikan pasti array multi dimensi,
	}
	public function get_single( $where = [], $nama_tabel = "data_landing_faq" ){
		// $where itu adalah array associatif [ "nama_kolom" => "value" ]
		// Jadi untuk mengambil single ini harus ada kondisi, gak boleh tidak ada 
		//Mengembalikan 1 dimensi dengan methode ->row_array()


		if ( count($where) > 0 ) {
			//Jika ada kondisinya 
			foreach ($where as $key_kolom => $value) {
				$this->db->where( $key_kolom, $value );
			}

			$result = $this->db->get( $nama_tabel )->row_array(); 
		}else{
			$result = [];
		}
		
		//Lakukan agar menjadi suatu penyetaraan yang dapat dihitung, jadi yang keluar itu pasti array
		if ( $result == null ) {
			$result = [];
		}
		return $result; //Mengembalikan pasti array 1 dimensi,

	}
	public function tambah(){

		$response = [];
		$pertanyaan = $this->input->post('pertanyaan');
		$jawaban = $this->input->post('jawaban');
		$waktu = $this->Base_model->waktu();
		$status = $this->Base_model->status();

		$data = array(
			'id_landing_faq' => null,
			'pertanyaan' => $pertanyaan,
			'jawaban' => $jawaban,
			'waktu' => $waktu,
			'status' => $status
		);
		$tambah_data = $this->db->insert('data_landing_faq', $data);
		if ( $tambah_data == true ) {
			$response['status'] = true ;
			$response['msg'] = "Data FAQ Landing berhasil ditambahkan";
		}else{
			$response['status'] = false;
			$response['msg'] = "Data FAQ Landing gagal ditambahkan, masalah query!!";
		}

		return $response;
	}

	public function update( $id_landing_faq ){

		$response = [];
		$pertanyaan = $this->input->post('pertanyaan');
		$jawaban = $this->input->post('jawaban');
		$waktu = $this->Base_model->waktu();
		$status = $this->Base_model->status();


		$data = array(
			'pertanyaan' => $pertanyaan,
			'jawaban' => $jawaban,
			'waktu' => $waktu,
			'status' => $status
		);
		$this->db->where('id_landing_faq', $id_landing_faq);
		$tambah_data = $this->db->update('data_landing_faq', $data);
		if ( $tambah_data == true ) {
			$response['status'] = true ;
			$response['msg'] = "Data FAQ Landing berhasil diupdate";
		}else{
			$response['status'] = false;
			$response['msg'] = "Data FAQ Landing gagal diupdate, masalah query!!";
		}

		return $response;
	}

}